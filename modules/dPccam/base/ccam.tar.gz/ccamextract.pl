#!/usr/bin/perl
# Script d'extraction des tables de la CCAM � partir du fichier CNAMTS au format NX complet
#   Copyright (C) 2003  Ren� BEDDOK

#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

# Version du 10/09/2005
# 01/02/2005 Correction d'un bug.
# 02/08/2005 la transcodification des caract�res est report�e dans traiter_enregistrement.
# 28/08/2005 Rajout dans  TBCCAM25 - TBCCAM31, TBCCAM34 de la date d'effet (CCAM26)
# 04/09/2005 suppression des enregistrements � 0 non significatifs des conditions g�n�rales
# 06/09/2005 suppression dans TB101 des informations de TB110
# 10/09/2005 extraction de TB00O
###############################################################################
#
use Getopt::Std;
$|=1; # Mode Autoflush pour STDOUT pour perl 5.6
# Param�tres modifiables par l'utilisateur
my $separ='|'; # Caract�re s�parateur de rubrique;
my $eol="\n";	# Caract�re s�parateur d'enregistrement;
my $nospace=1; # Si 1 Suppression des espaces en fin de champs 
my $debug=0;   # Si 1 on place au d�but de chaque enregistrement : Type d'enregistement, Rubrique , S�quence
#
# Nom des fichiers destination des tables concernant les actes proprement dits
# * Le nom du fichier est constitu� :
#  - par "TB" + <type enregistrement NX> lorsque un enregistrement correspond � une seule table
#  - par "TBCCAM" + < num�ro d'un champ CCAM > lorsqu'il a fallu cr�er des tables suppl�mentaires
# pour certains champs multivalu�s
my $OUT000="TB000.txt";
my $OUT101="TB101.txt";
my $OUT110="TB110.txt";
my $OUT120="TB120.txt";
my $OUT130="TB130.txt";
my $OUT201="TB201.txt";
my $OUT210="TB210.txt";
my $OUT301="TB301.txt";
my $OUT220="TB220.txt";
my $OUT310="TB310.txt";
my $OUT350="TB350.txt";
my $OUTCCAM03="TBCCAM03.txt";
my $OUTCCAM06="TBCCAM06.txt";
my $OUTCCAM9_1="TBCCAM9_1.txt";	# ? TB10
my $OUTCCAM10="TBCCAM10.txt";
my $OUTCCAM11="TBCCAM11.txt";
my $OUTCCAM20="TBCCAM20.txt";
my $OUTCCAM21="TBCCAM21.txt";
my $OUTCCAM32="TBCCAM32.txt";
my $OUTCCAM40="TBCCAM40.txt";
my $OUTCCAM41_1="TBCCAM41_1.txt";
my $OUTCCAM44="TBCCAM44.txt";

my $OUTCCAM25="TBCCAM25.txt"; # CODEACTE, EXONERATION
my $OUTCCAM31="TBCCAM31.txt"; # CODEACTE, SPECIALITE_PRESCRIPTEUR
my $OUTCCAM34="TBCCAM34.txt"; # CODEACTE, TYPE_FORFAIT

#
#
##############################################################################


##############################################################################
#
# Variables globales
my $f_ccam_nx ;# Variable globale contenant le nom du fichier contenant la CCAM au format NX
my $ligne;	# Variable globale contenant la ligne du fichier CCAM en cours de traitement;
##############################################################################


#Tables des formats d'enregistrements

# Table d�finissant les formats des enregistrements
# * Le premier �l�ment defini le type d'enregistrement
# 1 ligne  = N enregistrements : "1N"
# 1 ligne  = 1 enregistrement  : "11"
# N lignes = 1 enregistrement  : "N1"
# 
#* pour les enregistrements de type 1N 
# - Le deuxi�me �l�ment =  Nombre d'enregistrements par ligne
# - Le troisi�me �l�ment = Nombre de champs par enregistrement
#* Les autres �l�ments = longueurs des champs successifs
%format_enr =
			(
			"000  " => ["11",2,14,6,2,14,6,2,3,8,24,5,1,4], # le format �tant sp�cifique (pas de rubrique ni de s�quence) on triche en ins�rant un pseudo no de s�quence
			"00101" => ["1N",6,3,2,8,8,2,8,8,2,8,8,2,8,8,2,8,8,2,8,8],
			"00201" => ["1N",5,4,1,8,8,4,1,8,8,4,1,8,8,4,1,8,8,4,1,8,8,4],
			"00301" => ["1N",5,4,1,8,8,4,1,8,8,4,1,8,8,4,1,8,8,4,1,8,8,4],
			"00401" => ["1N",6,4,2,8,8,2,2,8,8,2,2,8,8,2,2,8,8,2,2,8,8,2,2,8,8,2],
			"00501" => ["1N",6,4,3,8,8,1,3,8,8,1,3,8,8,1,3,8,8,1,3,8,8,1,3,8,8,1],
			"00601" => ["1N",4,7,1,8,8,1,3,1,3,1,8,8,1,3,1,3,1,8,8,1,3,1,3,1,8,8,1,3,1,3], # 25/04/2005
			"00701" => ["1N",2,6,8,8,7,7,7,7,8,8,7,7,7,7],
			"00801" => ["1N",4,5,3,8,8,1,8,3,8,8,1,8,3,8,8,1,8,3,8,8,1,8],
			"00901" => ["1N",6,4,1,1,8,8,1,1,8,8,1,1,8,8,1,1,8,8,1,1,8,8,1,1,8,8],
			"01001" => ["1N",6,5,1,8,8,1,1,1,8,8,1,1,1,8,8,1,1,1,8,8,1,1,1,8,8,1,1,1,8,8,1,1],
			"01101" => ["1N",4,5,1,8,8,7,4,1,8,8,7,4,1,8,8,7,4,1,8,8,7,4],
			"01201" => ["1N",4,4,8,8,7,4,8,8,7,4,8,8,7,4,8,8,7,4],
			"01301" => ["1N",6,4,3,8,8,1,3,8,8,1,3,8,8,1,3,8,8,1,3,8,8,1,3,8,8,1],
			"01401" => ["1N",5,4,3,8,8,2,3,8,8,2,3,8,8,2,3,8,8,2,3,8,8,2],
			"01501" => ["1N",6,4,1,8,8,1,1,8,8,1,1,8,8,1,1,8,8,1,1,8,8,1,1,8,8,1],
			"01701" => ["1N",9,3,3,2,8,3,2,8,3,2,8,3,2,8,3,2,8,3,2,8,3,2,8,3,2,8,3,2,8],
			"01801" => ["1N",6,3,8,8,2,8,8,2,8,8,2,8,8,2,8,8,2,8,8,2],
			"01901" => ["1N",7,3,8,8,1,8,8,1,8,8,1,8,8,1,8,8,1,8,8,1,8,8,1],
			"02001" => ["1N",4,4,2,8,8,10,2,8,8,10,2,8,8,10,2,8,8,10], # 25/04/2005
			"05001" => ["11",2,100],
			"05101" => ["N1",4,100],
			"05201" => ["11",2,100],
			"05301" => ["11",1,80],
			"05401" => ["11",2,100],
			"05501" => ["11",1,80],
			"05601" => ["11",1,80],
			"05701" => ["11",1,80],
			"05801" => ["11",1,100],
			"05901" => ["11",1,100],
			"06001" => ["11",1,100],
			"06101" => ["11",2,100],
			"06201" => ["11",3,100],
			"06301" => ["11",2,100],
			"06401" => ["11",2,100],
			"06501" => ["11",1,80],
			"06601" => ["11",1,80],
			"06701" => ["11",2,80],
			"06801" => ["11",3,50],
			"08001" => ["11",1,100],
			"08101" => ["N1",1,100],
			"08201" => ["11",2,100],
			"08301" => ["11",1,100],
			"08401" => ["11",3,100],
			"09001" => ["1N",60,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
			"09101" => ["N1",6,6,6,100],
			"09201" => ["N1",6,2,100],
			"09301" => ["1N",7,3,3,8,6,3,8,6,3,8,6,3,8,6,3,8,6,3,8,6,3,8,6],
			"09901" => ["N1",50,50],
			"10101" => ["11",13,70,1,1,8,8],
			"10102" => ["11",[2,10],1],
			"10103" => ["11",[6,10],12,13,13,13] ,
			"10104" => ["11",[2,50]] , 
			"10150" => ["N1",100] ,
			"10151" => ["11",[4,30]] , 
			"10152" => ["N1",2,100] ,
			"11001" => ["11",8,8,8,1,1,[1,5],[2,10],[1,10]],
			"12001" => ["11",[13,8]],
			"13001" => ["11",[13,8]],
			"20101" => ["11",1,[1,10],[5,5],[2,10]],
			"20150" => ["N1",5,100],
			"21001" => ["11",8,8,8,[1,10],2,[2,10],3],
			"22001" => ["11",[14,8],[1,8]],
			"30101" => ["11",1,2,[2,52],3,3],
			"30150" => ["11",4,1],
			"31001" => ["11",8,8,8,2,3,6,1,6,[4,4],6],
			"35001" => ["11",8,6,6],
			"39901" => ["11",5],
			"29901" => ["11",5],
			"19901" => ["11",5]
			);



sub ccam_error
	{
	print $_[0];
	}
sub main
{
my @ligne;

my $ligne1;
my $type;
my $rubrique;
my $sequence;
my $typeformat;
my $formats;
my $indice=0;
my $codeacte;
my $i;

print 
"Script d'extraction des tables de la CCAM a partir du fichier CNAMTS au format NX complet
   Copyright (C) 2003  Rene BEDDOK

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.\n";   
# Gestion des options en ligne de commande
getopt('-cs'); 
# -c latin1 converti les caract�res sp�cifiques Windows1252 n'appartenant pas au charset latin1 (ISO-8859-1) �,�,� en leurs �quivalents oe, OE,'
# -s <caract�re s�parateur de champ>, si 'option n'est pas d�finie  la valeur par d�faut de $separ est conserv�e
# les caract�res sp�ciaux doivent �tre fournis sous la forme \n,\t,\r
$opt_s=~ s/\\t/\t/g;
$opt_s=~ s/\\n/\n/g;
$opt_s=~ s/\\r/\r/g;
$separ=($opt_s eq "" ? $separ : $opt_s);

if ($#ARGV >=0)
	{
	$f_ccam_nx=$ARGV[$#ARGV];
	}
else
	{
	die "\nusage : [perl] $0 [-c latin1] [-s <separateur>] <nom du fichier CCAM au format NX>\n
	     -c latin1 : converti les caracteres windows �,�,� en leurs equivalents oe,OE,\' \n
	     -s <separateur> : defini le caractere separateur de champ (defaut : |) ";
	}
open(CCAM,"<$f_ccam_nx") or die "Erreur � l'ouverture du fichier : $f_ccam_nx\n";

print "DEBUT DE L'EXTRACTION\n";
# Ouverture des fichiers ;
open(OUT101,">$OUT101");
open(OUT110,">$OUT110");
open(OUT120,">$OUT120");
open(OUT130,">$OUT130");
open(OUT201,">$OUT201");
open(OUT210,">$OUT210");
open(OUT301,">$OUT301");
open(OUT220,">$OUT220");
open(OUT310,">$OUT310");
open(OUT350,">$OUT350");
open(OUTCCAM03,">$OUTCCAM03");
open(OUTCCAM06,">$OUTCCAM06");
open(OUTCCAM9_1,">$OUTCCAM9_1");	# ? TB10
open(OUTCCAM10,">$OUTCCAM10");	
open(OUTCCAM11,">$OUTCCAM11");	
open(OUTCCAM20,">$OUTCCAM20");
open(OUTCCAM21,">$OUTCCAM21");
open(OUTCCAM32,">$OUTCCAM32");
open(OUTCCAM40,">$OUTCCAM40");
open(OUTCCAM41_1,">$OUTCCAM41_1");	
open(OUTCCAM44,">$OUTCCAM44");

open(OUTCCAM25,">$OUTCCAM25");
open(OUTCCAM31,">$OUTCCAM31");
open(OUTCCAM34,">$OUTCCAM34");	

$ligne=<CCAM>; # lecture de la premiere ligne
# V�rification qu'il s'agit du fichier CCAM NX COMPLET
if (substr($ligne,49,3) eq "CAM")
	{
	die "Erreur : Il s'agit du fichier CCAM format NX r�duit pour la tarification \n
	CCAMExtract ne traite que le fichier CCAM format NX COMPLET \n";
	}
if (substr($ligne,49,3) ne "CAC")
	{ die "Erreur : Il ne s'agit pas du fichier CCAM au format NX complet\n
	CCAMExtract ne traite que le fichier CCAM format NX COMPLET \n";
	}
#le format de la premi�re ligne �tant sp�cifique (pas de rubrique ni de s�quence) on triche en ins�rant un pseudo no de rubrique et de s�quence
$ligne=substr($ligne,0,5) . "0000" . substr($ligne,5);
print "EXTRACTION EN COURS, patientez \n";
$lasttype="";
#chomp($ligne=<CCAM>);
chomp($ligne);
while (!eof(CCAM))
	{
	($type,$rubrique,$sequence,@ligne)=decoupe_ligne($ligne);
	$indice=0;
	my $formats=$format_enr{substr($ligne,0,5)};
	my $typeformat= $$formats[$indice++];
	if ($typeformat eq "1N")
		{
		$nbe=@$formats[$indice++];
		$nbc=@$formats[$indice++];
		}

	if ($type <= 99) # il s'agit des Tables non actes
		{
		if ($type ne $lasttype) 
			{
			close(OUT);
			open(OUT, ">TB$type.txt");
			print "Extraction de la table TB$type\n";
			$lasttype=$type;
			}
		if ($typeformat eq "11")
			{
			traiter_enregistrement(OUT,($type,$rubrique,$sequence,@ligne));
			chomp($ligne=<CCAM>);
			}
		elsif ($typeformat eq "1N")
			{
			for ($i=0;$i<$nbe;$i++)
				{
				if (!estvide($ligne[$i*$nbc])) # �limine les enregistrement vides (cad ne comprenand que des espaces ou des z�ros)
					{
					traiter_enregistrement(OUT,($type,$rubrique,$sequence,@ligne[$i*$nbc..(($i+1)*$nbc)-1]));
					}
				}
			chomp($ligne=<CCAM>);
			}
		elsif ($typeformat eq "N1")
			{
			chomp($ligne1=<CCAM>);
			($type1,$rubrique1,$sequence1,@ligne1)=decoupe_ligne($ligne1);
			while (($type1 eq $type) and ($rubrique1 eq $rubrique) and ($sequence1 > $sequence))
				{
				$ligne[$#ligne].=$ligne1[$#ligne1];
				$type=$type1;$rubrique=$rubrique1;$sequence=$sequence1;
				chomp($ligne1=<CCAM>);
				($type1,$rubrique1,$sequence1,@ligne1)=decoupe_ligne($ligne1);
				}
			traiter_enregistrement(OUT,($type,$rubrique,$sequence,@ligne));
			$ligne=$ligne1;
			}
		
		}
	else #> 99
		{
		print "Extraction des actes \n";
		my $compteur=0;
		while ($type == 101)
			{
			if ($compteur==100)
				{
				$compteur=0;
				print ".";
				}
			$compteur++;
			traiter_101($type,$rubrique,$sequence,@ligne);
			chomp($ligne=<CCAM>);
			($type,$rubrique,$sequence,@ligne)=decoupe_ligne($ligne);
			}
		}		
	}
close CCAM;
print "\nEXTRACTION TERMINEE.\n";
}


# Renvoi VRAI (1) si la chaine ne contient que des espaces ou que des z�ros
sub estvide
	{$_=$_[0];
	return(m/^\s*$/ or m/^0*$/);
	}

sub traiter_enregistrement
	{

	my ($file,$type,$rubrique,$sequence,@ligne)=@_;
	if ($opt_c eq 'latin1')
	{
	foreach (@ligne) {
		s/�/oe/g; # Substitution des caract�res sp�cifiques windows (Win1252) ne faisant pas partie du standard latin1 ISO 8859-1
		s/�/OE/g;
		s/�/'/g;
	}
	}

	if ($nospace)
		{ # suppression des espaces en fin de champs;
		foreach (@ligne)
			{
			s/\s+$//;
			}
		}
	if ($debug)
		{
		print $file join($separ,($type,$rubrique,$sequence,@ligne)) . $eol;	
		}
		else
		{
		print $file join($separ,@ligne) . $eol;
		}
	}


# D�coupe une ligne selon son format dans la table %format_enr

sub decoupe_ligne
	{
	my ($i,$nbe,$nbc);
	my ($ligne)=@_;
	my $formats=$format_enr{substr($ligne,0,5)};
	my @result;
	my $debut=7;
	my ($longueur,$repet);
	my $indice=0;
	@result=(substr($ligne,0,3),substr($ligne,3,2),substr($ligne,5,2));
	my $type= @$formats[$indice++];
	if ($type eq "1N")
		{
		$nbe=@$formats[$indice++];
		$nbc=@$formats[$indice++];
	}
	$size=scalar(@$formats);
	for ($j = $indice; $j < $size; $j++)
		{
		$longueur=$$formats[$j];
		if (ref($longueur) eq "ARRAY") 
			{
			$repet=@$longueur[1];
			$longueur=@$longueur[0];
			}
		else
			{
			$repet=1;
			}
		for ($i =1;$i<=$repet;$i++)
			{
			push(@result,substr($ligne,$debut,$longueur));
			$debut+=$longueur;
			}
		}
	return(@result);
	}



sub traiter_101
{
my ($type,$rubrique,$sequence,@ligne)=@_;
my @result;
my ($codeacte,$libellecourt,$typeacte,$sexe,$datecreation,$datefin,
		@natureassurance,$fraisdep,@arborescence,$placearborescence,$codestructure,$codeprecedent,$codesuivant,$libellelong,
		@conditionG,@codenote,@textenote,$ccam26,$ccam27,$ccam28,$ccam22,$ccam24,@ccam25,@ccam31,@ccam34);
		
if ($rubrique eq "01")
	{
	($codeacte,$libellecourt,$typeacte,$sexe,$datecreation,$datefin)=@ligne;
	while ($type != 199) #Traitement de l'acte $codeacte
		{
		chomp($ligne=<CCAM>);
		($type,$rubrique,$sequence,@ligne)=decoupe_ligne($ligne);
		if (($type != 101) or ($rubrique ne "02") or ($sequence ne "01"))
			{
			ccam_error("Actes : $codeacte - Enregistrement : 1010201 manquant ; ligne -> $ligne \n");
			}
		else
			{
			(@natureassurance[0..9],$fraisdep)=@ligne;
			}
		chomp($ligne=<CCAM>);
		($type,$rubrique,$sequence,@ligne)=decoupe_ligne($ligne);
		if (($type != 101) or ($rubrique ne "03") or ($sequence ne "01"))
			{
			ccam_error("Actes : $codeacte - Enregistrement : 1010301 manquant \n");
			}
		else
			{
			(@arborescence[0..9],$placearborescence,$codestructure,$codeprecedent,$codesuivant)=@ligne;
			}
		chomp($ligne=<CCAM>);
		($type,$rubrique,$sequence,@ligne)=decoupe_ligne($ligne);
		$i=0;
		while (($type == 101) and ($rubrique eq "04"))
			{
			(@dmt[$i*50..(($i+1)*50)-1])=@ligne;
			$i++;
			chomp($ligne=<CCAM>);
			}
		if (($type != 101) or ($rubrique ne "50") or ($sequence ne "01"))
			{
			ccam_error("Actes : $codeacte - Enregistrement : 1015001 manquant \n");
			}
		else
			{
			chomp($ligne1=<CCAM>);
			($type1,$rubrique1,$sequence1,@ligne1)=decoupe_ligne($ligne1);
			while (($type1 eq $type) and ($rubrique1 eq $rubrique) and ($sequence1 > $sequence))
				{
				$ligne[$#ligne].=$ligne1[$#ligne1];
				$type=$type1;$rubrique=$rubrique1;$sequence=$sequence1;
				chomp($ligne1=<CCAM>);
				($type1,$rubrique1,$sequence1,@ligne1)=decoupe_ligne($ligne1);
				}
			($libellelong)=@ligne;
			
			$libellelong =~ s/\s+$//;

			$ligne=$ligne1;
			}
		($type,$rubrique,$sequence,@ligne)=decoupe_ligne($ligne);
		$i=0;
		while (($type == 101) and ($rubrique eq "51"))
			{
			(@conditionG[$i*30..(($i+1)*30)-1])=@ligne;
			$i++;
			chomp($ligne=<CCAM>);
			($type,$rubrique,$sequence,@ligne)=decoupe_ligne($ligne); #  07/01/2005 JM
			}
		($type,$rubrique,$sequence,@ligne)=decoupe_ligne($ligne);
		$i=0;
		while (($type == 101) and ($rubrique eq "52"))
			{
			chomp($ligne1=<CCAM>);
			($type1,$rubrique1,$sequence1,@ligne1)=decoupe_ligne($ligne1);
			while (($type1 eq $type) and ($rubrique1 eq $rubrique) and ($sequence1 > $sequence))
				{
				$ligne[$#ligne].=$ligne1[$#ligne1];
				$type=$type1;$rubrique=$rubrique1;$sequence=$sequence1;
				chomp($ligne1=<CCAM>);
				($type1,$rubrique1,$sequence1,@ligne1)=decoupe_ligne($ligne1);
				}
			($codenote[$i],$textenote[$i])=@ligne;
			$i++;
			$ligne=$ligne1;
			($type,$rubrique,$sequence,@ligne)=decoupe_ligne($ligne);
			}
		$i=1;
		while ($type == 110)
			{
			@result=traiter_110($codeacte,$type,$rubrique,$sequence,@ligne);
			if ($i==1) 
				{
				($ccam26,$ccam27,$ccam28,$ccam22,$ccam24,@ccam25[0..4],@ccam31[0..9],@ccam34[0..9])=@result;	
				}
			$i++;
#			chomp($ligne=<CCAM>);
			($type,$rubrique,$sequence,@ligne)=decoupe_ligne($ligne);
			}
		while ($type == 201)
			{
			traiter_201($codeacte,$type,$rubrique,$sequence,@ligne);
			chomp($ligne=<CCAM>);
			($type,$rubrique,$sequence,@ligne)=decoupe_ligne($ligne);
		}
#		foreach ($codeacte,$libellecourt,$typeacte,$sexe,$datecreation,$datefin,
#							@natureassurance[0..9],$fraisdep,
#							@arborescence[0..9],$placearborescence,$codestructure,$codeprecedent,$codesuivant,
#							$libellelong,
#							$ccam26,$ccam27,$ccam28,$ccam22,$ccam24,@ccam25[0..4],@ccam31[0..9],@ccam34[0..9])
#						{
#					s/\s+$//;
#						}

	traiter_enregistrement(OUT101,($type,$rubrique,$sequence,$codeacte,$libellecourt,$typeacte,$sexe,$datecreation,$datefin,
							@natureassurance[0..9],$fraisdep,
							@arborescence[0..9],$placearborescence,$codestructure,$codeprecedent,$codesuivant,
							$libellelong,
#							$ccam26,$ccam27,$ccam28,$ccam22,$ccam24,$ccam25,$ccam31,$ccam34) );
		# 06/09/2005 on ne prend plus ce qui fait partie de l'enregistrement 110   $ccam26,$ccam27,$ccam28,$ccam22,$ccam24
							) );
	foreach my $elem (@dmt) 
		{
		if ($elem ge '!')
			{ traiter_enregistrement(OUTCCAM41_1,($type,$rubrique,$sequence,$codeacte,$elem)); }
		}
	foreach my $elem (@conditionG) 
		{
#		if ($elem ge '!') 04/09/2005 suppression des enregistrements � 0 non significatifs
		if ($elem gt '0000')
			{ traiter_enregistrement(OUTCCAM10,($type,$rubrique,$sequence,$codeacte,$elem)); }
		}
	$i=0;
	foreach my $elem (@codenote) 
		{
		if ($elem ge '!')
			{ traiter_enregistrement(OUTCCAM11,($type,$rubrique,$sequence,$codeacte,$elem,$textenote[$i++])); }
		}
	
		
	}
	if ($type !=199) { print "Erreur : enregistrement 199 absent \n";}

	}
}

sub traiter_110
	{
	my ($ccam26,$ccam27,$ccam28,$ccam22,$ccam24,@ccam25,@ccam31,@ccam34);
	my ($codeacte,$type,$rubrique,$sequence,@ligne)=@_;
	#traitement de l'enregistrement 110
	my @sauve_ligne=@ligne;
	my $dateeffet=$ligne[0];
	#traitement de l'enregistrement 110
	traiter_enregistrement(OUT110,$type,$rubrique,$sequence,$codeacte,@ligne);
	chomp($ligne=<CCAM>);
	($type,$rubrique,$sequence,@ligne)=decoupe_ligne($ligne);
	while ($type == 120)
		{
		traiter_120($codeacte,$dateeffet,$type,$rubrique,$sequence,@ligne);
		chomp($ligne=<CCAM>);
		($type,$rubrique,$sequence,@ligne)=decoupe_ligne($ligne);
		}
	while ($type == 130)
		{
		traiter_130($codeacte,$dateeffet,$type,$rubrique,$sequence,@ligne);
		chomp($ligne=<CCAM>);
		($type,$rubrique,$sequence,@ligne)=decoupe_ligne($ligne);
		}
	($ccam26,$ccam27,$ccam28,$ccam22,$ccam24,@ccam25[0..4],@ccam31[0..9],@ccam34[0..9])=@sauve_ligne;
	foreach my $elem (@ccam25) 
		{
#		if ($elem ge '!') 25/04/2005 suppression des enregistrements � 0 non significatifs
		if ($elem gt '0')
			{ traiter_enregistrement(OUTCCAM25,($type,$rubrique,$sequence,$codeacte,$ccam26,$elem)); }
		}
	foreach my $elem (@ccam31) 
		{
		if ($elem ge '!')
			{ traiter_enregistrement(OUTCCAM31,($type,$rubrique,$sequence,$codeacte,$ccam26,$elem)); }
		}
	foreach my $elem (@ccam34) 
		{
		if ($elem ge '!')
			{ traiter_enregistrement(OUTCCAM34,($type,$rubrique,$sequence,$codeacte,$ccam26,$elem)); }
		}
	return(@sauve_ligne);
	}

sub traiter_120
	{
	my ($codeacte,$dateeffet,$type,$rubrique,$sequence,@ligne)=@_;
	foreach my $elem (@ligne) 
		{
		
		if ($elem ge 'A')
			{ traiter_enregistrement(OUT120,($type,$rubrique,$sequence,$codeacte,$dateeffet,$elem)); }
		}
	return($codeacte,$dateeffet,$ligne[0]);
	}

sub traiter_130
	{
	my ($codeacte,$dateeffet,$type,$rubrique,$sequence,@ligne)=@_;
	foreach my $elem (@ligne) 
		{
		if ($elem ge 'A')
			{ traiter_enregistrement(OUT130,($type,$rubrique,$sequence,$codeacte,$dateeffet,$elem)); }
		}
	return($codeacte,$dateeffet,$ligne[0]);
	}
	
sub traiter_201
	{
	my ($codeacte,$type,$rubrique,$sequence,@ligne)=@_;
	my ($codeactivite,@extensiondoc,@norecommendation,@agrementradio);
	($codeactivite,@extensiondoc[0..9],@norecommendation[0..5],@agrementradio[0..9])=@ligne;
	traiter_enregistrement(OUT201,($type,$rubrique,$sequence,$codeacte,$codeactivite));
	foreach my $elem (@extensiondoc) 
		{
		if ($elem ge '!')
			{ traiter_enregistrement(OUTCCAM03,($type,$rubrique,$sequence,$codeacte,$codeactivite,$elem))};
		}
	foreach my $elem (@norecommendation) 
		{
		if ($elem ge '!')
			{traiter_enregistrement(OUTCCAM20,($type,$rubrique,$sequence,$codeacte,$codeactivite,$elem));}
		}
	foreach my $elem (@agrementradio) 
		{
		if ($elem ge '!')
			{ traiter_enregistrement(OUTCCAM40,($type,$rubrique,$sequence,$codeacte,$codeactivite,$elem))};
		}
	chomp($ligne=<CCAM>);
	($type,$rubrique,$sequence,@ligne)=decoupe_ligne($ligne);
	while (($type ==201) and ($rubrique eq '50'))
		{
		traiter_enregistrement(OUTCCAM21,($type,$rubrique,$sequence,$codeacte,$codeactivite,@ligne));
		chomp($ligne=<CCAM>);
		($type,$rubrique,$sequence,@ligne)=decoupe_ligne($ligne);
		}
	while ($type == 210)
		{
		traiter_210($codeacte,$codeactivite,$type,$rubrique,$sequence,@ligne);
#		chomp($ligne=<CCAM>);
		($type,$rubrique,$sequence,@ligne)=decoupe_ligne($ligne);
		}
	while ($type == 301)
		{
		traiter_301($codeacte,$codeactivite,$type,$rubrique,$sequence,@ligne);
		chomp($ligne=<CCAM>);
		($type,$rubrique,$sequence,@ligne)=decoupe_ligne($ligne);
		}
	if ($type != 299)
		{
		print "Erreur : enregistrement 399 absent \n : ligne -> $ligne ";
		}

	}

sub traiter_210
	{
	my ($codeacte,$codeactivite,$type,$rubrique,$sequence,@ligne)=@_;
	my ($dateeffet,$datearrete,$datepublication,@codemodificateur,
		$categoriemedicale,@specialite,$regroupement);
	($dateeffet,$datearrete,$datepublication,@codemodificateur[0..9],
		$categoriemedicale,@specialite[0..9],$regroupement)=@ligne;
	foreach my $elem (@codemodificateur) 
		{
		if ($elem ge '!')
			{ traiter_enregistrement(OUTCCAM06,($type,$rubrique,$sequence,$codeacte,$codeactivite,$dateeffet,$elem))};
		}
	foreach my $elem (@specialite) 
		{
		if ($elem ge '!')
			{ traiter_enregistrement(OUTCCAM32,($type,$rubrique,$sequence,$codeacte,$codeactivite,$dateeffet,$elem))};
		}
	traiter_enregistrement(OUT210,($type,$rubrique,$sequence,$codeacte,$codeactivite,$dateeffet,$datearrete,
				$datepublication,$categoriemedicale,$regroupement));
	chomp($ligne=<CCAM>);
	($type,$rubrique,$sequence,@ligne)=decoupe_ligne($ligne);	
	while ($type == 220)
		{
		traiter_220($codeacte,$codeactivite,$dateeffet,$type,$rubrique,$sequence,@ligne);
		chomp($ligne=<CCAM>);
		($type,$rubrique,$sequence,@ligne)=decoupe_ligne($ligne);
		}
	}
	
sub traiter_301
	{
	my ($codeacte,$codeactivite,$type,$rubrique,$sequence,$phase,$nbdents,@dentsincompatibles,$agemini,$agemaxi);
	($codeacte,$codeactivite,$type,$rubrique,$sequence,$phase,$nbdents,@dentsincompatibles[0..51],$agemini,$agemaxi)=@_;
	my ($icr,$classant);
	foreach my $elem (@dentsincompatibles) 
		{
		if ($elem gt '00') # car les elements vides sont � "00" et pas � "  "
			{ traiter_enregistrement(OUTCCAM44,($type,$rubrique,$sequence,$codeacte,$codeactivite,$phase,$elem));};
		}
	chomp($ligne=<CCAM>);
	($type,$rubrique,$sequence,@ligne)=decoupe_ligne($ligne);
	if (($type == 301) and ($rubrique = "50"))
		{
		($icr,$classant)=@ligne;
		chomp($ligne=<CCAM>);
		($type,$rubrique,$sequence,@ligne)=decoupe_ligne($ligne);
		}
	traiter_enregistrement(OUT301,($type,$rubrique,$sequence,$codeacte,$codeactivite,$phase,$nbdents,$agemini,$agemaxi,$icr,$classant));
	while (($type == 310) or ($type == 350))
		{
		while ($type == 310)
			{
			traiter_310($codeacte,$codeactivite,$phase,$type,$rubrique,$sequence,@ligne);
			chomp($ligne=<CCAM>);
			($type,$rubrique,$sequence,@ligne)=decoupe_ligne($ligne);
			}
		while ($type == 350) 
			{
			traiter_350($codeacte,$codeactivite,$phase,$type,$rubrique,$sequence,@ligne);
			chomp($ligne=<CCAM>);
			($type,$rubrique,$sequence,@ligne)=decoupe_ligne($ligne);
			}
		}
	if ($type !=399) { print "Erreur : enregistrement 399 absent ligne -> $ligne \n";}
	}

sub traiter_220
	{
	my ($codeacte,$codeactivite,$dateeffet,$type,$rubrique,$sequence,@codeacteactivite,@regletarifaire);
	($codeacte,$codeactivite,$dateeffet,$type,$rubrique,$sequence,@codeacteactivite[0..7],@regletarifaire[0..7])=@_;
	my $i=0;
	foreach my $elem (@codeacteactivite) 
		{
		if ($elem ge '!')
			{ traiter_enregistrement(OUT220,($type,$rubrique,$sequence,$codeacte,$codeactivite,$dateeffet,substr($elem,0,13),substr($elem,13,1),$regletarifaire[$i++]));};
		}
	}

sub traiter_310
	{
	my ($codeacte,$codeactivite,$phase,$type,$rubrique,$sequence,@ligne)=@_;
	traiter_enregistrement(OUT310,($type,$rubrique,$sequence,$codeacte,$codeactivite,$phase,@ligne));
	}

sub traiter_350
	{
	my ($codeacte,$codeactivite,$phase,$type,$rubrique,$sequence,$dateffet,$score,$coutpratique)=@_;
	traiter_enregistrement(OUT350,($type,$rubrique,$sequence,$codeacte,$codeactivite,$phase,$dateffet,$score,$coutpratique));
	}

main();

